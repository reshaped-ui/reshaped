export { default } from "./Image";
export type { Props as ImageProps } from "./Image.types";
