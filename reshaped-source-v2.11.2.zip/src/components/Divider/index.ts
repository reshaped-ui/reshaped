export { default } from "./Divider";
export type { Props as DividerProps } from "./Divider.types";
