export { default } from "./View";
export type { Props as ViewProps, ItemProps as ViewItemProps } from "./View.types";
