export { default } from "./HiddenInput";
export type { Props as HiddenInputProps } from "./HiddenInput.types";
