export { default } from "./TextArea";
export type { Props as TextAreaProps } from "./TextArea.types";
