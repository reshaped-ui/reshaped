export { default } from "./Card";
export type { Props as CardProps } from "./Card.types";
