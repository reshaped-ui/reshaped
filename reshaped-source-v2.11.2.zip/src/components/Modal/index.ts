export { default } from "./Modal";
export type { Props as ModalProps } from "./Modal.types";
