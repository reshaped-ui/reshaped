export { default } from "./ScrollArea";
export type { Props as ScrollAreaProps } from "./ScrollArea.types";
