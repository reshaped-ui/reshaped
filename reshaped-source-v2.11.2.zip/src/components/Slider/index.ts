export { default } from "./Slider";
export type { Props as SliderProps } from "./Slider.types";
