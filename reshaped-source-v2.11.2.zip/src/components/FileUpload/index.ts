export { default } from "./FileUpload";
export type { Props as FileUploadProps } from "./FileUpload.types";
