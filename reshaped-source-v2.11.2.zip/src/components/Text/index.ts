export { default } from "./Text";
export type { Props as TextProps } from "./Text.types";
