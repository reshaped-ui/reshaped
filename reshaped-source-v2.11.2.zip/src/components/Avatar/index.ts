export { default } from "./Avatar";
export type { Props as AvatarProps } from "./Avatar.types";
