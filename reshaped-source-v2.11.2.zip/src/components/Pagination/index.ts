export { default } from "./Pagination";
export type { Props as PaginationProps } from "./Pagination.types";
