export const regExpNumericChar = "\\d";
export const regExpAlphabeticChar = "[a-zA-Z]";
export const regExpAlphaNumericChar = `(${regExpNumericChar}|${regExpAlphabeticChar})`;
