export { default } from "./Scrim";
export type { Props as ScrimProps } from "./Scrim.types";
