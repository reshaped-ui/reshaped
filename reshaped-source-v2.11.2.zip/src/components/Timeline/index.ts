export { default } from "./Timeline";
export type { Props as TimelineProps, ItemProps as TimelineItemProps } from "./Timeline.types";
