export { default } from "./Loader";
export type { Props as LoaderProps } from "./Loader.types";
