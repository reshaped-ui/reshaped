export { default } from "./Tabs";
export type { Props as TabsProps, ItemProps as TabsItemProps } from "./Tabs.types";
