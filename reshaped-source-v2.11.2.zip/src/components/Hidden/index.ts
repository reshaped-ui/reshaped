export { default } from "./Hidden";
export type { Props as HiddenProps } from "./Hidden.types";
