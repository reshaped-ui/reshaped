export type Name = "fast" | "medium" | "slow";
export type Token = { ms: number };
