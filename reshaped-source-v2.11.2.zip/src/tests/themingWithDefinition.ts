/**
 * File importing theming client to test its bundle size
 */
import * as themes from "themes/index";

console.log(themes);
