export const mouseEnter = 100;
export const mouseLeave = 150;
