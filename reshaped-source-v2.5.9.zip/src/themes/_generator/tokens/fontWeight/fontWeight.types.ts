export type Name = "regular" | "medium" | "semibold" | "bold" | "heavy" | "black";
export type Token = { weight: number };
