export type Name = "title" | "body";
export type Token = { family: string };
