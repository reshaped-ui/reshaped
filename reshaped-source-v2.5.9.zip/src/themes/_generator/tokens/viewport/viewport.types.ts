export type Name = "s" | "m" | "l" | "xl";
export type Token = { minPx?: number; maxPx?: number };
