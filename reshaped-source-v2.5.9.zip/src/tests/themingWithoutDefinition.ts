/**
 * File importing theming client to test its bundle size
 */
import { getThemeCSS, generateThemeColors } from "themes/index";

console.log({ getThemeCSS, generateThemeColors });
