export { default } from "./Table";
export type { Props as TableProps } from "./Table.types";
