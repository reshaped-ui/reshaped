export { default } from "./Link";
export type { Props as LinkProps } from "./Link.types";
