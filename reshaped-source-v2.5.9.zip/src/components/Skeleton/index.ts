export { default } from "./Skeleton";
export type { Props as SkeletonProps } from "./Skeleton.types";
