export { default } from "./Aligner";
export type { Props as AlignerProps } from "./Aligner.types";
