export { default } from "./Autocomplete";
export type { Props as AutocompleteProps } from "./Autocomplete.types";
