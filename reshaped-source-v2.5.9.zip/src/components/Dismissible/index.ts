export { default } from "./Dismissible";
export type {
	Props as DismissibleProps,
	CloseProps as DismissibleCloseProps,
} from "./Dismissible.types";
