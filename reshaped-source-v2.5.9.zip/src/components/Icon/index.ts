export { default } from "./Icon";
export type { Props as IconProps } from "./Icon.types";
