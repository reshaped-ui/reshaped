export { default } from "./Badge";
export type { Props as BadgeProps } from "./Badge.types";
