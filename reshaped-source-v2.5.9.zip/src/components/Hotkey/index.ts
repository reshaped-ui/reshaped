export { default } from "./Hotkey";
export type { Props as HotkeyProps } from "./Hotkey.types";
