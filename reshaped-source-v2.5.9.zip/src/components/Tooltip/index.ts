export { default } from "./Tooltip";
export type { Props as TooltipProps } from "./Tooltip.types";
