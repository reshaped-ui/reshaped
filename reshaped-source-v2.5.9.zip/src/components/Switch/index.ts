export { default } from "./Switch";
export type { Props as SwitchProps } from "./Switch.types";
