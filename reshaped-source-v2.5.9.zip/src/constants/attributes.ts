export const keyboardModeAttribute = "data-rs-keyboard";
export const pseudoFocusAttribute = "data-rs-focus";
